/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.registro.CRUD.repository;

import com.registro.CRUD.model.Persona;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 *
 * @author JOEL
 */
public interface PersonaRepository extends JpaRepository <Persona, Long> {
    
}
